require 'rails_helper'

feature "ReaderReadsABlogPosts", :type => :feature do
  scenario "does exist without comments" do
  	Post.create(
  		title: "Hello World",
  		author: "Jane Burgen",
  		content: "Lorem Ipsum dolar sit amet"
  		)
  	visit '/'
  	click_link("post")
  	expect(page).to have_content("Hello World")
  	expect(page).to have_content("Jane Burgen")
  	expect(page).to have_content("Lorem Ipsum dolar sit amet")
  	expect(page).not_to have_content("comments")
  end

  scenario "does exist with comments" do
  	 post = Post.create(
  	 	title: "Hello World",
  		author: "Jane Burgen",
  		content: "Lorem Ipsum dolar sit amet"
  	 	)

  	 post.comments.create(
  	 	message: "I hate candy and babies!",
  	 	author: "John"
  	 	)
  	 
  	visit '/'
  	click_link("post")
  	expect(page).to have_content("Hello World")
  	expect(page).to have_content("Jane Burgen")
  	expect(page).to have_content("Lorem Ipsum dolar sit amet")
  	
  	expect(page).to have_content("comments")
  	
  	expect(page).to have_content("John")
  	expect(page).to have_content("I hate candy and babies!")
  end
end
